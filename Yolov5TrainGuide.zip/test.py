from packages import yolov5
import cv2

detector = yolov5.Detector(weights="packages/yolov5/models/pt/yolov5s.pt")

cam = cv2.VideoCapture(0)

ms = 1
while cam.isOpened():
    ret, frame = cam.read()
    pred = detector.detect(frame, True)
    detector.draw_bb(frame, pred)
    cv2.imshow("test", frame)
    key = cv2.waitKey(ms)
    if key == ord(" "):
        ms = 1 - ms
    if key == 27:
        cv2.destroyAllWindows()
        break
