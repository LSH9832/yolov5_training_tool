Before using this tool, please install requirements.
First, make sure CUDA, CUDNN, pytorch and torchvision are correctly installed and then install the following requirements

$ pip3 install -r requirements.txt


Open this tool

$ python3 main.py


Note:
If you don't used wandb in this machine before, please login your wandb account and initialize your wandb enviroment.
If you don't have an account for wandb please register one.(website: https://wandb.ai/)

$ wandb login

follow the wandb guide and then you can successfully use this tool
you can run "wandb offline" to turn off syncing.
