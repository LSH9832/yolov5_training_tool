from Yolov5TrainGuide_ui2py import Ui_Yolov5TrainGuide as MAIN

from sys             import argv, exit

from PyQt5.QtCore    import QTimer
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui     import QIcon

from PyQt5           import QtWidgets
# import multiprocessing as mp
import os
import pickle

this_dir = str(os.path.realpath(__file__)).replace(str(os.path.realpath(__file__)).replace('\\', '/').split('/')[-1], '')


# 主窗口
#######################################################################################################################
class MainWindow(QMainWindow, MAIN):

    # 初始化函数
    ###################################################################################################################
    def __init__(self, parent=None, train_fun = None):

        super(MainWindow, self).__init__(parent)
        super(MainWindow, self).setupUi(self)
        # loadUi('main.ui', self)

        # 固定窗口大小
        self.setFixedSize(self.size())

        # 加载图标
        self.loadIcon()

        self.timer = QTimer()  # 定时器，或者计时器， whatever
        self.timer.start(200)  # 开始每2000毫秒自动运行下一行连接的函数，一般用于更新界面，根据需求一般设置为10-20毫秒左右
        self.timer.timeout.connect(self.timeoutFun)   # 每2000毫秒自动运行一次的函数


        # 激活全部按钮、菜单选项、下拉列表用于测试，实际使用时注释掉
        self.create_dir.setEnabled(True)
        self.prepare.setEnabled(True)
        self.generate_code.setEnabled(True)
        self.choose_model.setEnabled(False)

        self.model_size.setEnabled(True)

        # 事件连接函数
        self.create_dir.clicked.connect(self.create_dir_ClickFun)
        self.prepare.clicked.connect(self.prepare_ClickFun)
        self.generate_code.clicked.connect(self.generate_code_ClickFun)
        self.browse.clicked.connect(self.browse_ClickFun)
        self.choose_model.clicked.connect(self.choose_model_ClickFun)

        self.default_model.clicked.connect(self.enable_choose)
        self.other_model.clicked.connect(self.enable_choose)

        self.model_size.currentIndexChanged.connect(self.model_size_ClickFun)

        # train_data_preparation
        self.train = None
        self.data_train = train_fun
        self.model_weight_file = None

    def enable_choose(self):
        self.choose_model.setEnabled(self.other_model.isChecked())

    # 按钮
    def choose_model_ClickFun(self):
        directory = QtWidgets.QFileDialog.getOpenFileName(None,
                                                          "Choose File",
                                                          "/home/" + os.popen("echo $USERNAME").read().strip("\n"),
                                                          "pt Files (*.pt);;All Files (*)")
        if os.path.exists(directory[0]):
            self.model_weight_file = directory[0]
            self.textBrowser.setText("Weight file " + self.model_weight_file + " is choosen to be trained.")

    def browse_ClickFun(self):
        directory = QtWidgets.QFileDialog.getExistingDirectory(None,
                                                               "Choose Location",
                                                               "/home/" + os.popen("echo $USERNAME").read().strip("\n"))  # 起始路径
        self.location.setText(directory)


    def create_dir_ClickFun(self):
        print("你按了 " + self.create_dir.text() + " 这个按钮")

        self.train = self.data_train.Preparation(address=self.location.text(), dir_name=self.data_name.text(), classes=('a', 'b'))
        self.train.create_data_dir()

        self.textBrowser.setText("Data dir has been created in " + self.location.text() + ", please read file READ_ME.txt in dir " + self.data_name.text())
        self.location.setEnabled(False)
        self.data_name.setEnabled(False)



    def prepare_ClickFun(self):
        print("你按了 " + self.prepare.text() + " 这个按钮")
        if self.train is None:
            self.train = self.data_train.Preparation(address=self.location.text(), dir_name=self.data_name.text(), classes=('a', 'b'))
        ret, msg = self.train.check_data()
        if not ret:
            self.textBrowser.setText('[ERROR]:' + msg)
        else:
            location = self.location.text()
            if location.startswith("~"):
                location = "/home/" + os.popen("echo $USERNAME").read().strip("\n") + location[1:]
            if not location.endswith("/") or location.endswith("\\"):
                location += "/"

            labels = []
            for label in open(location + self.data_name.text() + "/label.txt").readlines():
                labels.append(str(label).rstrip("\n"))
            labels = tuple(labels)
            self.train.classes = labels
            # print(self.train.classes)

            print('creating training data and test data')
            # print(self.per.value()/100)
            self.train.split_data(train_percent=self.per.value()/100)  # 将数据集分为训练集和验证集
            print('creating txt label')
            self.train.create_voc_label()  # 将xml文件转化为yolo能够识别的格式的数据并保存为txt文件于label文件夹中
            print('creating data yaml')
            self.train.create_yaml()  # 在主目录中创建含有数据集信息的yaml文件
            print('clauculating anchors')
            self.train.clauculate_anchors()  # 计算最佳anchors并保存在主目录anchors.txt中
            print('creating cfg yaml')
            self.train.create_cfg()  # yolo模型文件
            print("done")
            self.textBrowser.setText('done')


    def generate_code_ClickFun(self):
        print("你按了 " + self.generate_code.text() + " 这个按钮")
        location = self.location.text()
        if location.startswith("~"):
            location = "/home/" + os.popen("echo $USERNAME").read().strip("\n") + location[1:]
        if not location.endswith("/") or location.endswith("\\"):
            location += "/"

        if self.train is None:
            labels = []
            for label in open(location + self.data_name.text() + "/label.txt").readlines():
                labels.append(str(label).rstrip("\n"))
            labels = tuple(labels)
            self.train = self.data_train.Preparation(address=self.location.text(), dir_name=self.data_name.text(), classes=labels)

        print(self.model_size.currentText().split('(')[1].split(')')[0], self.batch_size.value(), self.epochs.value())

        option = self.train.get_train_options(net_type=self.model_size.currentText().split('(')[1].split(')')[0],
                                     epochs=self.epochs.value(),
                                     batch_size=self.batch_size.value(),
                                     othermodel=self.model_weight_file if self.other_model.isChecked() else None)

        # print(type(self.data_name.text()))
        pickle.dump(option, open(location + self.data_name.text() + "/option",'wb'))

        if os.path.exists(option.default_hyp):
            hyp_file = open(location + self.data_name.text() + "/hyp.yaml", 'w')
            hyp_file.write(open(option.default_hyp).read())
            hyp_file.close()

        codetext = open(this_dir + 'TrainCodeModel.py').read().replace("$MODULE_PATH", this_dir[:-1])
        run_file = open(location + self.data_name.text() + "/start_train.py", 'w')
        run_file.write(codetext)
        run_file.close()


        show_string = "Done.\n" \
                      "Now you can open " + location + self.data_name.text() + "/hyp.yaml and tune hyperparameters.\n"\
                      "Then open Terminal and input the following commands to start training.\n\n" \
                      "cd " + location + self.data_name.text() + "\n" \
                      "python3 start_train.py"
        self.textBrowser.setText(show_string)



    # 菜单选项

    # 下拉列表
    def model_size_ClickFun(self):
        print("你将该下拉列表选项变成了 " + self.model_size.currentText())


    # 自动运行的函数
    def timeoutFun(self):
        location = self.location.text()
        if location.startswith("~"):
            location = "/home/" + os.popen("echo $USERNAME").read().strip("\n") + location[1:]
            # print(location)
        if bool(len(location)) and not location.endswith("/") or location.endswith("\\"):
            location += "/"

        flag1 = os.path.exists(location)
        flag2 = bool(len(self.data_name.text()))

        create_dir = False
        prepare = False
        generate = False

        if flag1 and flag2:
            if not os.path.exists(location + self.data_name.text()):
                create_dir = True
            if os.path.exists(location + self.data_name.text()):
                if not self.location.isEnabled():
                    if os.path.exists(location + self.data_name.text() + "/label.txt"):
                        prepare = True
                elif os.path.exists(location + self.data_name.text() + "/READ_ME.txt"):
                    if os.path.exists(location + self.data_name.text() + "/label.txt"):
                        prepare = True
                if os.path.exists(location + self.data_name.text() + "/anchors.txt"):
                    generate = True
                    if self.other_model.isChecked() and self.model_weight_file is None:
                        generate = False
        self.create_dir.setEnabled(create_dir)
        self.prepare.setEnabled(prepare)
        self.generate_code.setEnabled(generate)

    # 加载图标
    def loadIcon(self):
        # 若需要加上图标，请将图标文件名改成icon.[ico,jpg,bmp,png]这些图片格式都可以
        try:
            import icon
            self.setWindowIcon(QIcon(icon.GetImg().toqpixmap()))

        # 编译成exe文件时将except部分的代码删去，换成pass即可
        except:
            # pass
            try:
                from packages import img2py
                img2py('icon.ico')
                from os.path import exists
                while not exists('icon.py'):
                    pass
                import icon
                self.setWindowIcon(QIcon(icon.GetImg().toqpixmap()))
            except:
                imgtype = ['jpg', 'png', 'bmp', 'gif', 'jpeg']
                flag = 0
                from packages import img2py
                for t in imgtype:
                    try:
                        img2py('icon.' + t)
                        flag = 1
                        break
                    except:
                        pass
                if flag:
                    import icon
                    self.setWindowIcon(QIcon(icon.GetImg().toqpixmap()))
                else:
                    print('未找到图标文件')


def main():
    app = QApplication(argv)
    from packages.yolov5 import data_train
    w = MainWindow(train_fun=data_train)
    w.show()
    exit(app.exec())


if __name__ == '__main__':
    # mp.freeze_support()
    main()
